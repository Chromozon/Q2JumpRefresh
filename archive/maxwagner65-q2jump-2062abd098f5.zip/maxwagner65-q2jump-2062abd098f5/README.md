# Quake II Jump Mod
### What it is
Jump mod isolates the unique movement from Quake II, like strafe and double jumping, and turns it into a competition. 
The goal is to get the fastest time from when you spawn, until when you reach the railgun at the end of the map. 
In between the spawn and the railgun is a number of obstacles that you have to get over as quickly as possible. 

***
### Compiling
The code should compile using windows or linux. 
Included is a makefile for linux and visual studio .sln / .def / .vcproj files for compiling on windows. 
To compile on linux, run the makefile with gcc. To compile on Windows, Visual Studio Express 2008 has worked for most people. 
Send a question if you cannot get it to compile. 

***
### Credits
| Name            | Credit
| ---             | ---
| SadButTrue      | original programmer
| ManicMiner      | producer for 0 - 0.81
| wootwoot        | programmer for 0.81 - 0.83wp
| LilRedTheJumper | programmer for 0.84wp
| ace             | programmer for 1.08ger - current
| 754(slippery)   | programmer for 1.12ger - current
| draxi           | programmer for 1.14ger - current
| fish            | various scripts for discord integration
| quadz           | fix_users_file script
| maq             | last_place_fix/duplicate checker scripts
| SumFuka         | jetpack code
| Killerbee       | q2admin code
| Doyoon Kim      | ball model
| Hannibal_       | bug fixes
| DeathJump       | adminbox additional colors